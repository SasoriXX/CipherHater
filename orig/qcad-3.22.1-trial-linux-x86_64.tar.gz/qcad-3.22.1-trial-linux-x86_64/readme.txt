QCAD

This is QCAD version 3.22.

QCAD is an application for computer aided drafting (CAD) in two dimensions (2D).

With QCAD you can create technical drawings such as plans for buildings, 
interiors, mechanical parts or schematics and diagrams.

QCAD works on Windows, macOS and many Linux and Unix Systems. The source code 
of QCAD is distributed under the GPLv3 (see LICENSE.txt for details).
