include("UcCncMM.js");

/**
 * Configuration for UCCNC controllers.
 * Output in Millimeters.
 */
function UcCncMy(documentInterface, camDocumentInterface) {
    UcCncMM.call(this, documentInterface, camDocumentInterface);

    //this.offsetJoin = RS.JoinMiter;
}

UcCncMy.prototype = new UcCncMM();
UcCncMy.displayName = "UCCNC (My) [mm]";

UcCncMy.prototype.initPass = function(pass, numberOfPasses) {
//    var toolDiameter = this.getToolDiameter(true);
//    var maxOffset = this.currentToolpathBlock.getCustomProperty("QCAD", "CamMaxOffset", undefined);
//    if (isNull(maxOffset)) {
//        //this.setToolDiameterOverride(toolDiameter);
//    }
//    else {
//        this.setToolDiameterOverride(toolDiameter / numberOfPasses * pass * maxOffset);
//    }
};

UcCncMy.prototype.uninitPass = function(pass, numberOfPasses) {
    //this.unsetToolDiameterOverride();
};
