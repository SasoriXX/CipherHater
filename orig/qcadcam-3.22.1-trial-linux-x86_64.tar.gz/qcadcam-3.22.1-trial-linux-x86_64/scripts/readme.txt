This folder contains some example scripts of QCAD.

QCAD contains hundreds of more scripts than those in this folder. However, 
those are distributed as compiled plugins for faster installation and loading.
If you prefer to have all available scripts as individual files in this folder, 
you can download them as part of the source code distribution (see QCAD.org 
download page). Simply copy the contents of the 'scripts' folder into this folder. 

Scripts available in this folder always take priority over scripts in plugins. 
You can update a script by keeping its file in this directory (or in the 
appropriate sub directory). It's usually not necessary to delete the 'qcadscripts' 
plugin after installing the script file sources.
